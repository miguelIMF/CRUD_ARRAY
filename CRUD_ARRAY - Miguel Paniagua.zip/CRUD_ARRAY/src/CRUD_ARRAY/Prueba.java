package CRUD_ARRAY;
import java.util.ArrayList;

public class Prueba {

	private static ArrayList<String> titulos;

	public static void llenarLista() {
		titulos = new ArrayList<String>();
		titulos.add("Una noche en la opera");
		titulos.add("Indiana Jones y la última cruzada");
		titulos.add("La lista de Schindler");
		titulos.add("Sucedió una noche");
	}

public static void mostrarLista() {
System.out.println("Lista de películas:");
for (String pelicula : titulos) {
System.out.println(pelicula);
    }
  }

}
